package com.rosten

class RostenTagLib {
	static namespace = "r"

	def jsLoad = {attrs->
		def g = new org.codehaus.groovy.grails.plugins.web.taglib.ApplicationTagLib()
		def jsurl = g.resource(dir:attrs.dir, file: attrs.file)
		out<<"<script type='text/javascript' src='"+jsurl+"'></script>"
	}
	def cssLoad = {attrs->
		def g = new org.codehaus.groovy.grails.plugins.web.taglib.ApplicationTagLib()
		def cssurl = g.resource(dir:attrs.dir, file: attrs.file)
		if(attrs.id && !"".equals(attrs.id)){
			out<<"<link rel='stylesheet' type='text/css' id='" + attrs.id + "' href='"+cssurl+"'></link>"
		}else{
			out<<"<link rel='stylesheet' type='text/css' href='"+cssurl+"'></link>"
		}
	}
}
